NOTE : SC JANGAN DIPERJUAL BELIKAN
REUPLOAD ? BOLEH
RECODE ? BOLEH
JUAL ? MATI AJA LU SUU


 //━━━━━━━━━━━━━━━[ ᴄᴏᴍᴍᴀɴᴅ ]━━━━━━━━━━━━━━━\\
 $ pkg upgrade && pkg update
 $ pkg install nodejs
 $ pkg install ffmpeg
 $ pkg install imagemagick
 $ termux-setup-storage
 $ cd /sdcard
 $ cp -r zakstore /$HOME
 $ cd
 $ cd zakstore
 $ npm install
 $ npm start
 
 //━━━━━━━━━━━━━━━[ ᴘʀᴏᴍᴏsɪ ]━━━━━━━━━━━━━━━\\
 Yang No Enc Ke Owner Langsung / Editin Bisik Bisik :v
 Contact Owner : wa.me/6285878313791
 NOTE : Jika Mau Tanya Sesuatu Gausah Spam Jika Tidak Mau Di Block